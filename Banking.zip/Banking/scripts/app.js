/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
var bankingModule =angular.module("BankingModule",['LoanModule']);
bankingModule.run(function($rootScope) {
    $rootScope.bankName="ICICI";
});
bankingModule.controller('CustomerController',['$scope',function($scope)
{
    //customer model
    $scope.customerobj={
        "customerId":0,
        "customerName":"",
        "address":""
    }
    $scope.CustomerInfo=function()
    {
        console.log($scope.customerobj.customerId);
        console.log($scope.customerobj.customerName);
        console.log($scope.customerobj.address);
    }

}]);


angular.element(document).ready(function() {
    angular.bootstrap(document, ['BankingModule']);
});