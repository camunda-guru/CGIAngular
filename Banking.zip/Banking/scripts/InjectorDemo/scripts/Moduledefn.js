/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
var userModule=angular.module('UserModule',[]);