/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
userModule.factory('RESTFactory',['UserService','PostService',function(UserService,PostService)
{
    var serviceInstance={};
    var InvokeService=function(type)
    {
        if(type=='Users')
         seviceInstance=UserService;
        if(type='Posts')
            seviceInstance=PostService;
    }
    return serviceInstance;
}]);