/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */

userModule.constant('serviceOptions',['Users','Posts','Albums','Comments','Photos'])

userModule.controller('UserController',['$scope','serviceOptions','$http',function($scope,serviceOptions,$http)
{
     $scope.options=serviceOptions;
     $scope.type="";
     urlval="";
     $scope.typeChange=function()
     {
            console.log($scope.type);
           //if($scope.type=='Users')
             // urlval='http://jsonplaceholder.typicode.com/users';
         //if($scope.type=='Posts')
             //urlval='http://jsonplaceholder.typicode.com/posts';


             //var value= $scope.dataSets[keyName ];


         }





}]);