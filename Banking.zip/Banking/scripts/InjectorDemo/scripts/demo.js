/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */

userModule.constant('serviceOptions',['Users','Posts','Albums','Comments','Photos'])

userModule.controller('UserController',
    ['$scope','serviceOptions','RESTFactory',
        function($scope,serviceOptions,RESTFactory)
{
     $scope.options=serviceOptions;
     $scope.type="";

     $scope.typeChange=function()
     {
            console.log($scope.type);
         Service = RESTFactory.InvokeService($scope.type);
         console.log(Service);
        Service.getService().then(function(info)
        {
           console.log(info.data);
            $scope.obj=info.data;
        }, function(error) {
            // promise rejected, could log the error with: console.log('error', error);
            console.log(error);
        });


         }





}]);