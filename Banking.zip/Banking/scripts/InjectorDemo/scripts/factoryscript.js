/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
userModule.factory('RESTFactory',['UserService','PostService',function(UserService,PostService)
{
    var serviceInstance={};
    serviceInstance.InvokeService=function(type)
    {
        if(type=="Users")
         serviceInstance=UserService;
        if(type=="Posts")
            serviceInstance=PostService;
        return serviceInstance;
    }
    return serviceInstance;
}]);