/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
userModule.service('UserService',['$http',function($http)
{
    var InvokeUserData=function() {
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/json'

            },
            url: 'http://jsonplaceholder.typicode.com/users'
        }).success(function (data) {
            console.log(data);
             return data;


        })
    }

    return{
        getUserService:InvokeUserData
    }
}])

userModule.service('PostService',['$http',function($http)
{
    var InvokePostData=function() {
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/json'

            },
            url: 'http://jsonplaceholder.typicode.com/posts'
        }).success(function (data) {
            console.log(data);
            return data;


        })
    }

    return{
        getPostService:InvokePostData
    }
}])