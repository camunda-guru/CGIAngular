/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
userModule.service('UserService',['$q','$http',function($q,$http)
{
    var InvokeUserData=function() {
        var def = $q.defer();
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/json'

            },
            url: 'http://jsonplaceholder.typicode.com/users'
        }).success(function (data) {
            console.log("resolve");
            return  def.resolve(data);
        }).error(function(err) {
            return def.reject("Failed to get users"+err);
        });
    }

    return{
        getService:InvokeUserData
    }
}])

userModule.service('PostService',['$q','$http',function($q,$http)
{
    var InvokePostData=function() {
        var def = $q.defer();
        return $http({
            method: 'GET',
            dataType: "jsonp",
            headers: {
                'Content-Type': 'application/json'

            },
            url: 'http://jsonplaceholder.typicode.com/posts'
        }).success(function (data) {
            console.log("resolve");
            return  def.resolve(data);
        }).error(function(err) {
            return def.reject("Failed to get users"+err);
        });
    }

    return{
        getService:InvokePostData
    };
}])