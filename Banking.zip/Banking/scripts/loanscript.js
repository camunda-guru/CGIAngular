/**
 * Created by BALASUBRAMANIAM on 22-08-2016.
 */
var loanModule=angular.module('LoanModule',[]);

loanModule.controller('HomeLoanController',['$scope',function($scope)
{
       $scope.homeloanobj={
           "name":"Home Loan",
           "roi":0.14,
           "MaxLoanPeriod":20
       }

}]);
loanModule.controller('CarLoanController',['$scope',function($scope)
{
    $scope.carloanobj={
        "name":"Car Loan",
        "roi":0.15,
        "MaxLoanPeriod":7
    }

}]);