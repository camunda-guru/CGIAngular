/**
 * Created by BALASUBRAMANIAM on 24-08-2016.
 */
var userModule =angular.module('UserModule',['ngRoute']);

var routerConfiguration=function($routeProvider)
{
     $routeProvider.
         when('/users/:userId',{
         templateUrl : 'userDetails.html',
         controller : 'DetailsController'
          }).
         when('/posts/:userName/:userId',{
             templateUrl : 'posts.html',
             controller : 'PostController'
         }).
         otherwise({
             redirectTo: '/'
         });
}

userModule.config(['$routeProvider', routerConfiguration]);


userModule.controller('UserController',['$scope','$http',function($scope,$http)
{
    $http({
        method: 'GET',
        dataType: "jsonp",
        headers: {
            'Content-Type': 'application/json'
        },
        url: 'http://jsonplaceholder.typicode.com/users'
    }).success(function (info) {
        console.log(info);
        $scope.obj=info;
    }).error(function(err) {
        console.log(err);
    });
}]);


userModule.controller('DetailsController',
    ['$scope','$http','$routeParams',function($scope,$http,$routeParams)
{
      console.log($routeParams.userId);
    $http({
        method: 'GET',
        dataType: "jsonp",
        headers: {
            'Content-Type': 'application/json'
        },
        url: 'http://jsonplaceholder.typicode.com/users/'+$routeParams.userId
    }).success(function (info) {
        console.log(info);
        $scope.userInfo=info;
    }).error(function(err) {
        console.log(err);
    });

}]);

userModule.controller('PostController',['$scope','$http','$routeParams',function($scope,$http,$routeParams)
{
     console.log($routeParams.userName);
     console.log($routeParams.userId);

    $http({
        method: 'GET',
        dataType: "jsonp",
        headers: {
            'Content-Type': 'application/json'
        },
        url: 'http://jsonplaceholder.typicode.com/posts?userId='+$routeParams.userId
    }).success(function (info) {
        console.log(info);
        $scope.postInfo=info;
    }).error(function(err) {
        console.log(err);
    });
}]);
