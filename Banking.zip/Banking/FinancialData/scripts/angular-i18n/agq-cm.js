require('./angular-locale_agq-cm');
module.exports = 'ngLocale';
