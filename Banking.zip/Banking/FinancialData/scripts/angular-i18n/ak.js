require('./angular-locale_ak');
module.exports = 'ngLocale';
